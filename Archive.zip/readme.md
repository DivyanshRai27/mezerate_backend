<p align="center">
  <a href="https://mezerate.ams3.digitaloceanspaces.com/Logo/icon.png">
    <img src="https://mezerate.ams3.digitaloceanspaces.com/Logo/icon.png" alt="Logo" width="80" height="80">
  </a>

  <h3 align="center">Mezerate</h3>

  <p align="center">
    Get your studies stuff here!!
    <br />
    <a href="https://mezerate.com"><strong>Explore the website »</strong></a>
    
  </p>
</p>

## ScreenShot
<a href="https://mezerate.ams3.digitaloceanspaces.com/Logo/Screenshot%202020-08-20%20at%201.18.52%20PM.png">
    <img src="https://mezerate.ams3.digitaloceanspaces.com/Logo/Screenshot%202020-08-20%20at%201.18.52%20PM.png" alt="Logo" width="1080" height="500">
  </a>